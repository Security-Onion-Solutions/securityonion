# Copyright 2022-2026 Broadcom.
# SPDX-License-Identifier: Apache-2.0
import hashlib
import logging
import pathlib
import sys

import pytest

from relenv.build.common import Dirs, get_dependency_version
from relenv.build.common.builder import Builder
from relenv.build.common.download import Download, verify_checksum
from relenv.build.common.ui import (
    BuildStats,
    LineCountHandler,
    load_build_stats,
    save_build_stats,
    update_build_stats,
)
from relenv.common import DATA_DIR, RelenvException, toolchain_root_dir, work_dirs

# mypy: ignore-errors


@pytest.fixture
def fake_download(tmp_path: pathlib.Path) -> pathlib.Path:
    download = tmp_path / "fake_download"
    download.write_text("This is some file contents")
    return download


@pytest.fixture
def fake_download_md5(fake_download: pathlib.Path) -> str:
    return hashlib.sha1(fake_download.read_bytes()).hexdigest()


@pytest.fixture
def fake_download_sha256(fake_download: pathlib.Path) -> str:
    return hashlib.sha256(fake_download.read_bytes()).hexdigest()


@pytest.mark.skip_unless_on_linux
def test_builder_defaults_linux() -> None:
    builder = Builder(version="3.10.10")
    assert builder.arch == "x86_64"
    assert builder.arch == "x86_64"
    assert builder.triplet == "x86_64-linux-gnu"
    assert builder.prefix == DATA_DIR / "build" / "3.10.10-x86_64-linux-gnu"
    assert builder.sources == DATA_DIR / "src"
    assert builder.downloads == DATA_DIR / "download"
    assert builder.toolchain == toolchain_root_dir() / builder.triplet
    assert callable(builder.build_default)
    assert callable(builder.populate_env)
    assert builder.recipies == {}


@pytest.mark.skip_unless_on_linux
def test_builder_toolchain_lazy_loading(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test that toolchain is only fetched when accessed (lazy loading)."""
    import relenv.common

    call_count = {"count": 0}

    def mock_get_toolchain(arch=None, root=None):
        call_count["count"] += 1
        # Return a fake path instead of actually extracting
        return pathlib.Path(f"/fake/toolchain/{arch or 'default'}")

    # Patch where get_toolchain is actually imported and used (in relenv.common)
    monkeypatch.setattr(relenv.common, "get_toolchain", mock_get_toolchain)

    # Create builder - should NOT call get_toolchain yet
    builder = Builder(version="3.10.10", arch="aarch64")
    assert call_count["count"] == 0, "get_toolchain should not be called during init"

    # Access toolchain property - should call get_toolchain once
    toolchain = builder.toolchain
    assert call_count["count"] == 1, "get_toolchain should be called when property is accessed"
    assert toolchain == pathlib.Path("/fake/toolchain/aarch64")

    # Access again - should use cached value, not call again
    toolchain2 = builder.toolchain
    assert call_count["count"] == 1, "get_toolchain should only be called once (cached)"
    assert toolchain == toolchain2

    # Change arch - should reset cache
    builder.set_arch("x86_64")
    assert builder._toolchain is None, "Changing arch should reset toolchain cache"

    # Access after arch change - should call get_toolchain again
    toolchain3 = builder.toolchain
    assert call_count["count"] == 2, "get_toolchain should be called again after arch change"
    assert toolchain3 == pathlib.Path("/fake/toolchain/x86_64")


def test_verify_checksum(fake_download: pathlib.Path, fake_download_md5: str) -> None:
    assert verify_checksum(fake_download, fake_download_md5) is True


def test_verify_checksum_sha256(fake_download: pathlib.Path, fake_download_sha256: str) -> None:
    """Test SHA-256 checksum validation."""
    assert verify_checksum(fake_download, fake_download_sha256) is True


def test_verify_checksum_failed(fake_download: pathlib.Path) -> None:
    pytest.raises(RelenvException, verify_checksum, fake_download, "no")


def test_verify_checksum_none(fake_download: pathlib.Path) -> None:
    """Test that verify_checksum returns False when checksum is None."""
    assert verify_checksum(fake_download, None) is False


def test_verify_checksum_invalid_length(fake_download: pathlib.Path) -> None:
    """Test that invalid checksum length raises error."""
    with pytest.raises(RelenvException, match="Invalid checksum length"):
        verify_checksum(fake_download, "abc123")  # 6 chars, not 40 or 64


def test_get_dependency_version_openssl_linux() -> None:
    """Test getting OpenSSL version for Linux platform."""
    result = get_dependency_version("openssl", "linux")
    assert result is not None
    assert isinstance(result, dict)
    assert "version" in result
    assert "url" in result
    assert "sha256" in result
    assert isinstance(result["version"], str)
    assert "openssl" in result["url"].lower()
    assert "{version}" in result["url"]
    assert isinstance(result["sha256"], str)


def test_get_dependency_version_sqlite_all_platforms() -> None:
    """Test getting SQLite version for various platforms."""
    for platform in ["linux", "darwin", "win32"]:
        result = get_dependency_version("sqlite", platform)
        assert result is not None, f"SQLite should be available for {platform}"
        assert isinstance(result, dict)
        assert "version" in result
        assert "url" in result
        assert "sha256" in result
        assert "sqliteversion" in result, "SQLite should have sqliteversion field"
        assert isinstance(result["version"], str)
        assert "sqlite" in result["url"].lower()
        assert isinstance(result["sha256"], str)


def test_get_dependency_version_xz_all_platforms() -> None:
    """Test getting XZ version for various platforms."""
    # XZ 5.5.0+ removed MSBuild support, so Windows uses a fallback version
    # BUT we now have XZ 5.8.2 in python-versions.json for win32 too
    for platform in ["linux", "darwin", "win32"]:
        result = get_dependency_version("xz", platform)
        assert result is not None, f"XZ should be available for {platform}"
        assert isinstance(result, dict)
        assert "version" in result
        assert "url" in result
        assert "sha256" in result
        assert isinstance(result["version"], str)
        assert "xz" in result["url"].lower()
        assert isinstance(result["sha256"], str)


def test_get_dependency_version_nonexistent() -> None:
    """Test that nonexistent dependency returns None."""
    result = get_dependency_version("nonexistent-dep", "linux")
    assert result is None


def test_get_dependency_version_wrong_platform() -> None:
    """Test that requesting unsupported platform returns None."""
    # Try to get OpenSSL for a platform that doesn't exist
    result = get_dependency_version("openssl", "nonexistent-platform")
    assert result is None


# Build stats tests


def test_build_stats_save_load(tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test saving and loading build statistics."""
    monkeypatch.setattr("relenv.build.common.ui.DATA_DIR", tmp_path)

    # Save some stats
    stats = {
        "python": BuildStats(avg_lines=100, samples=1, last_lines=100),
        "openssl": BuildStats(avg_lines=200, samples=2, last_lines=180),
    }
    save_build_stats(stats)

    # Load them back
    loaded = load_build_stats()
    assert loaded["python"]["avg_lines"] == 100
    assert loaded["python"]["samples"] == 1
    assert loaded["python"]["last_lines"] == 100
    assert loaded["openssl"]["avg_lines"] == 200
    assert loaded["openssl"]["samples"] == 2


def test_build_stats_load_nonexistent(tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test loading stats when file doesn't exist returns empty dict."""
    monkeypatch.setattr("relenv.build.common.ui.DATA_DIR", tmp_path)
    loaded = load_build_stats()
    assert loaded == {}


def test_build_stats_update_new_step(tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test updating stats for a new build step."""
    monkeypatch.setattr("relenv.build.common.ui.DATA_DIR", tmp_path)

    # Update a new step
    update_build_stats("python", 100)

    # Load and verify
    stats = load_build_stats()
    assert stats["python"]["avg_lines"] == 100
    assert stats["python"]["samples"] == 1
    assert stats["python"]["last_lines"] == 100


def test_build_stats_update_existing_step(tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test updating stats for an existing step uses exponential moving average."""
    monkeypatch.setattr("relenv.build.common.ui.DATA_DIR", tmp_path)

    # Initial value
    update_build_stats("python", 100)

    # Update with new value
    update_build_stats("python", 200)

    # Load and verify exponential moving average: 0.7 * 200 + 0.3 * 100 = 170
    stats = load_build_stats()
    assert stats["python"]["avg_lines"] == 170
    assert stats["python"]["samples"] == 2
    assert stats["python"]["last_lines"] == 200


# LineCountHandler tests


def test_line_count_handler() -> None:
    """Test LineCountHandler increments shared dict correctly."""
    shared_dict = {}
    handler = LineCountHandler("test", shared_dict)

    # Create a log record
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="test message",
        args=(),
        exc_info=None,
    )

    # Emit first record
    handler.emit(record)
    assert shared_dict["test"] == 1

    # Emit second record
    handler.emit(record)
    assert shared_dict["test"] == 2

    # Emit third record
    handler.emit(record)
    assert shared_dict["test"] == 3


def test_line_count_handler_multiple_steps() -> None:
    """Test LineCountHandler tracks multiple steps independently."""
    shared_dict = {}
    handler1 = LineCountHandler("step1", shared_dict)
    handler2 = LineCountHandler("step2", shared_dict)

    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="test",
        args=(),
        exc_info=None,
    )

    handler1.emit(record)
    handler1.emit(record)
    handler2.emit(record)

    assert shared_dict["step1"] == 2
    assert shared_dict["step2"] == 1


# Dirs class tests


@pytest.mark.skip_unless_on_linux
def test_dirs_initialization() -> None:
    """Test Dirs class initialization."""
    dirs = Dirs(work_dirs(), "python", "x86_64", "3.10.0")
    assert dirs.name == "python"
    assert dirs.arch == "x86_64"
    assert dirs.version == "3.10.0"
    assert "python_build" in dirs.tmpbuild


def test_dirs_triplet_darwin(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test Dirs._triplet property for darwin platform."""
    monkeypatch.setattr("sys.platform", "darwin")
    dirs = Dirs(work_dirs(), "test", "arm64", "3.10.0")
    assert dirs._triplet == "arm64-macos"


def test_dirs_triplet_win32(monkeypatch: pytest.MonkeyPatch) -> None:
    """Test Dirs._triplet property for win32 platform."""
    monkeypatch.setattr("sys.platform", "win32")
    dirs = Dirs(work_dirs(), "test", "amd64", "3.10.0")
    assert dirs._triplet == "amd64-win"


@pytest.mark.skip_unless_on_linux
def test_dirs_triplet_linux() -> None:
    """Test Dirs._triplet property for linux platform."""
    dirs = Dirs(work_dirs(), "test", "x86_64", "3.10.0")
    assert dirs._triplet == "x86_64-linux-gnu"


@pytest.mark.skip_unless_on_linux
def test_dirs_prefix() -> None:
    """Test Dirs.prefix property."""
    dirs = Dirs(work_dirs(), "test", "x86_64", "3.10.0")
    assert "3.10.0-x86_64-linux-gnu" in str(dirs.prefix)


@pytest.mark.skip_unless_on_linux
def test_dirs_to_dict() -> None:
    """Test Dirs.to_dict() method."""
    dirs = Dirs(work_dirs(), "test", "x86_64", "3.10.0")
    d = dirs.to_dict()
    assert "root" in d
    assert "prefix" in d
    assert "downloads" in d
    assert "logs" in d
    assert "sources" in d
    assert "build" in d
    assert "toolchain" in d


@pytest.mark.skip_unless_on_linux
def test_dirs_pickle() -> None:
    """Test Dirs serialization/deserialization."""
    dirs = Dirs(work_dirs(), "python", "x86_64", "3.10.0")

    # Get state
    state = dirs.__getstate__()
    assert state["name"] == "python"
    assert state["arch"] == "x86_64"

    # Create new instance and restore state
    dirs2 = Dirs.__new__(Dirs)
    dirs2.__setstate__(state)
    assert dirs2.name == "python"
    assert dirs2.arch == "x86_64"
    assert dirs2.tmpbuild == dirs.tmpbuild


# Download class tests


def test_download_copy() -> None:
    """Test Download.copy() creates independent copy."""
    d1 = Download(
        "test",
        "http://example.com/{version}/test.tar.gz",
        version="1.0.0",
        checksum="abc123",
    )
    d2 = d1.copy()

    # Verify copy has same values
    assert d2.name == d1.name
    assert d2.url_tpl == d1.url_tpl
    assert d2.version == d1.version
    assert d2.checksum == d1.checksum

    # Verify it's a different object
    assert d2 is not d1

    # Verify modifying copy doesn't affect original
    d2.version = "2.0.0"
    assert d1.version == "1.0.0"
    assert d2.version == "2.0.0"


def test_download_fallback_url() -> None:
    """Test Download.fallback_url property."""
    d = Download(
        "test",
        "http://main.com/{version}/test.tar.gz",
        fallback_url="http://backup.com/{version}/test.tar.gz",
        version="1.0.0",
    )
    assert d.fallback_url == "http://backup.com/1.0.0/test.tar.gz"


def test_download_no_fallback() -> None:
    """Test Download.fallback_url returns None when not configured."""
    d = Download("test", "http://example.com/{version}/test.tar.gz", version="1.0.0")
    assert d.fallback_url is None


def test_download_signature_url() -> None:
    """Test Download.signature_url property."""
    d = Download(
        "test",
        "http://example.com/{version}/test.tar.gz",
        signature="http://example.com/{version}/test.tar.gz.asc",
        version="1.0.0",
    )
    assert d.signature_url == "http://example.com/1.0.0/test.tar.gz.asc"


def test_download_signature_url_error() -> None:
    """Test Download.signature_url raises error when not configured."""
    from relenv.common import ConfigurationError

    d = Download("test", "http://example.com/test.tar.gz")
    with pytest.raises(ConfigurationError, match="Signature template not configured"):
        _ = d.signature_url


def test_download_destination_setter() -> None:
    """Test Download.destination setter with None value."""
    d = Download("test", "http://example.com/test.tar.gz")

    # Set to a path
    d.destination = "/tmp/downloads"
    assert d.destination == pathlib.Path("/tmp/downloads")

    # Set to None
    d.destination = None
    assert d.destination == pathlib.Path()


# copy_pyconfig_h tests
#
# Regression coverage for the bug where Windows onedirs for Python 3.13+ were
# shipped without Include/pyconfig.h, breaking every C extension build.
# Python <= 3.12 has a checked-in PC/pyconfig.h; Python 3.13+ replaced it
# with PC/pyconfig.h.in and MSBuild generates the real header into the
# PCbuild output directory. copy_pyconfig_h must pick the right one.


def _make_layout(
    tmp_path: pathlib.Path,
    *,
    has_in: bool,
    pc_content: str = "",
    build_content: str = "",
) -> tuple[pathlib.Path, pathlib.Path, pathlib.Path]:
    """Create source/, build_dir/, dest_dir/ trees mimicking a CPython tree."""
    source = tmp_path / "cpython"
    build_dir = tmp_path / "PCbuild" / "amd64"
    dest_dir = tmp_path / "prefix" / "Include"
    (source / "PC").mkdir(parents=True)
    build_dir.mkdir(parents=True)
    dest_dir.mkdir(parents=True)
    if has_in:
        (source / "PC" / "pyconfig.h.in").write_text("/* template */\n")
        if build_content:
            (build_dir / "pyconfig.h").write_text(build_content)
    else:
        if pc_content:
            (source / "PC" / "pyconfig.h").write_text(pc_content)
    return source, build_dir, dest_dir


def test_populate_env_sets_host_python() -> None:
    """
    CPython's PCbuild/find_python.bat only looks for a pre-installed
    bootstrap interpreter via specific "py -X.Y" versions (e.g. 3.10's copy
    of the script only tries 3.9/3.8), both of which are EOL and age out of
    CI images over time; when neither is found it falls back to an
    unreliable NuGet download. HOST_PYTHON is checked before either of
    those, so populate_env should point it at the interpreter already
    running the build.
    """
    from relenv.build.windows import populate_env

    dirs = Dirs(work_dirs(), "python", "amd64", "3.10.20")
    env: dict[str, str] = {}
    populate_env(env, dirs)
    assert env["HOST_PYTHON"] == sys.executable


def test_copy_pyconfig_h_legacy(tmp_path: pathlib.Path) -> None:
    """Python <= 3.12: copies PC/pyconfig.h (no pyconfig.h.in template)."""
    from relenv.build.windows import copy_pyconfig_h

    source, build_dir, dest_dir = _make_layout(tmp_path, has_in=False, pc_content="/* checked in 3.12 */\n")
    # Ensure the build_dir variant would NOT be picked up if it happened to
    # exist as well -- the legacy path takes precedence when there's no .in.
    (build_dir / "pyconfig.h").write_text("/* should be ignored */\n")

    result = copy_pyconfig_h(source, build_dir, dest_dir)

    assert result == dest_dir / "pyconfig.h"
    assert result.is_file()
    assert result.read_text() == "/* checked in 3.12 */\n"


def test_copy_pyconfig_h_generated(tmp_path: pathlib.Path) -> None:
    """Python 3.13+: copies the generated pyconfig.h from build_dir."""
    from relenv.build.windows import copy_pyconfig_h

    source, build_dir, dest_dir = _make_layout(tmp_path, has_in=True, build_content="/* generated 3.13 */\n")
    # A stale PC/pyconfig.h must NOT win when pyconfig.h.in is present.
    (source / "PC" / "pyconfig.h").write_text("/* stale legacy */\n")

    result = copy_pyconfig_h(source, build_dir, dest_dir)

    assert result == dest_dir / "pyconfig.h"
    assert result.is_file()
    assert result.read_text() == "/* generated 3.13 */\n"


def test_copy_pyconfig_h_missing_generated_raises(tmp_path: pathlib.Path) -> None:
    """3.13+ layout but MSBuild didn't produce pyconfig.h -- must raise.

    This is the failure mode that previously slipped through silently and
    produced unusable tarballs.
    """
    from relenv.build.windows import copy_pyconfig_h

    source, build_dir, dest_dir = _make_layout(tmp_path, has_in=True)
    # No pyconfig.h written into build_dir.

    with pytest.raises(RuntimeError, match="Expected pyconfig.h at"):
        copy_pyconfig_h(source, build_dir, dest_dir)
    assert not (dest_dir / "pyconfig.h").exists()


def test_copy_pyconfig_h_missing_legacy_raises(tmp_path: pathlib.Path) -> None:
    """Legacy layout but PC/pyconfig.h is absent -- must raise rather than silently no-op."""
    from relenv.build.windows import copy_pyconfig_h

    source, build_dir, dest_dir = _make_layout(tmp_path, has_in=False)
    # No pyconfig.h written into PC/ either.

    with pytest.raises(RuntimeError, match="Expected pyconfig.h at"):
        copy_pyconfig_h(source, build_dir, dest_dir)
    assert not (dest_dir / "pyconfig.h").exists()


def test_patch_ssl_for_cpython_104135_appends_when_marker_missing(tmp_path: pathlib.Path) -> None:
    """The helper writes the patch body into Lib/ssl.py and adds the marker."""
    from relenv.build.windows import _SSL_PATCH_MARKER, patch_ssl_for_cpython_104135

    (tmp_path / "Lib").mkdir()
    ssl_py = tmp_path / "Lib" / "ssl.py"
    original = '"""stub ssl module."""\n\nclass SSLContext: pass\nclass SSLError(Exception): pass\n'
    ssl_py.write_text(original, encoding="utf-8")

    patch_ssl_for_cpython_104135(tmp_path)

    patched = ssl_py.read_text(encoding="utf-8")
    assert patched.startswith(original)
    assert _SSL_PATCH_MARKER in patched
    assert "_load_windows_store_certs" in patched


def test_patch_ssl_for_cpython_104135_is_idempotent(tmp_path: pathlib.Path) -> None:
    """Applying twice leaves exactly one marker (no double append)."""
    from relenv.build.windows import _SSL_PATCH_MARKER, patch_ssl_for_cpython_104135

    (tmp_path / "Lib").mkdir()
    ssl_py = tmp_path / "Lib" / "ssl.py"
    ssl_py.write_text("# stub\n", encoding="utf-8")

    patch_ssl_for_cpython_104135(tmp_path)
    after_first = ssl_py.read_text(encoding="utf-8")
    patch_ssl_for_cpython_104135(tmp_path)
    after_second = ssl_py.read_text(encoding="utf-8")

    assert after_first == after_second
    assert after_second.count(_SSL_PATCH_MARKER) == 1


def test_patch_ssl_for_cpython_104135_missing_file_is_noop(
    tmp_path: pathlib.Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """A source tree without Lib/ssl.py logs a warning and does not raise."""
    from relenv.build.windows import patch_ssl_for_cpython_104135

    with caplog.at_level(logging.WARNING, logger="relenv.build.windows"):
        patch_ssl_for_cpython_104135(tmp_path)

    assert any("Lib/ssl.py not found" in r.message for r in caplog.records)
    assert not (tmp_path / "Lib").exists()


def test_patch_ssl_for_cpython_104135_body_is_valid_python() -> None:
    """The appended block must compile cleanly as a Python module."""
    from relenv.build.windows import _SSL_PATCH_BODY

    # ssl.py defines SSLError / SSLContext at module scope; supply stubs so
    # the patch body resolves the same names when concatenated.
    preamble = "class SSLError(Exception): pass\nclass SSLContext: pass\n"
    compile(preamble + _SSL_PATCH_BODY, "<patched_ssl>", "exec")
